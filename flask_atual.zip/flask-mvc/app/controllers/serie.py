# -*- coding: utf-8 -*-
from flask import render_template, request,redirect
from flask import Blueprint, flash, Flask
from app.models.Form import formulario
from app.models.login import formLogin
from app.models.formserie import formSerie
from app.models.usuario import Usuario
from app.models.classes.serie import Serie
from flask_sqlalchemy import SQLAlchemy
#from app.models.serverDao import db
#from app.models.daoTemporada import TemporadaDAO
#from app.models.daoSerie import SerieDAO
#from app.models.serie import Serie
#from app.models.temporada import Temporada
#from app.models.dao import UsuarioDAO

from app import db


serie = Blueprint('serie', __name__, url_prefix='/serie')

@serie.route('/listarSerie')
def listarSerie():
    lista = Serie.query.all()
    return render_template('printer/listarSerie.html',lista = lista)

@serie.route('/deletar/<cod>')
def deletar(cod):
    Serie.query.filter_by(id=cod).delete()
    db.session.commit()
    return redirect('/serie/listarSerie')

@serie.route('/alterar/<cod>')
def alterar(cod):
    form = F()
    if form.validate_on_submit():
        user = Usuario()
        user.email = form.email.data
        user.altura = form.altura.data
        user.idade = form.idade.data
        user.login = form.login.data
        user.nome = form.nome.data
        user.senha = form.senha.data
        db.session.add(user)
        db.session.commit()
        return "inserido com sucesso!"
    return redirect('/serie/listarSerie')


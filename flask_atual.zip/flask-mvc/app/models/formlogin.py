from flask_wtf import FlaskForm
from wtforms import SubmitField,StringField,DecimalField,RadioField,PasswordField,TextAreaField,IntegerField,HiddenField
from wtforms.validators import DataRequired,Optional, Length
from wtforms_components import EmailField
from flask_bootstrap import Bootstrap
from flask_babel import Babel
class formLogin(FlaskForm):
    tipo = "cadastro"
    senha = PasswordField('Senha',validators=[DataRequired()])
    login = StringField('Login',validators=[DataRequired()])
    enviar = SubmitField('Enviar')

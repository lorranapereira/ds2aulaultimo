from flask import Flask
from flask_sqlalchemy import SQLAlchemy
app = Flask(__name__,template_folder="template")
db =  SQLAlchemy(app)
#deixar flask_sql.. e db = ... em outra pasta db
#padrao active record
uri = 'postgresql://postgres:@localhost:5432/banco'
app.config['SQLALCHEMY_DATABASE_URI'] = uri
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.secret_key = 'chave secreta'
db.init_app(app)
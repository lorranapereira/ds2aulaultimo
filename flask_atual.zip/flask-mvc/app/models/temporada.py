class Temporada:
    def __init__(self, numero,FK_serie_cod,cod = None):
        self._numero = numero
        self._cod = cod
    def _get_descricao(self):
        return self._descricao
    def _set_descricao(self, descricao):
        self._descricao = descricao
    def _get_cod(self):
        return self._cod
    def _set_cod(self, cod):
        self._cod = cod
    def _get_FK_serie_cod(self):
        return self._FK_serie_cod
    def _set_FK_serie_cod(self, FK_serie_cod):
        self._FK_serie_cod = FK_serie_cod
    def _get_numero(self):
        return self._numero
    def _set_numero(self, numero):
        self._numero = numero
    def __str__(self):
        return "Codigo: {}, numero: {}".format(self.cod,self.numero)

    numero = property( _get_numero, _set_numero)
    descricao = property( _get_descricao, _set_descricao)
    FK_serie_cod = property( _get_FK_serie_cod, _set_FK_serie_cod)
    cod = property( _get_cod, _set_cod)

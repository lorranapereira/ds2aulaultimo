from app import db
#devo tirar o not null de sericod e adiconar altura
class Usuario(db.Model):
    __tablename__ = 'usuario'
    id = db.Column(db.Integer, primary_key=True)
    seriecod = db.Column(db.Integer)
    senha = db.Column(db.String(100), nullable=False)
    altura = db.Column(db.Float)
    login = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(100), nullable=False)
    idade = db.Column(db.Integer)
    

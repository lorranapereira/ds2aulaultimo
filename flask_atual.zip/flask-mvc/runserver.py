#!/usr/bin/env python
# -*- coding: utf-8 -*-
import os
from app import app
from flask import Blueprint
from flask import redirect, url_for
from app.controllers.control import control
from app.controllers.usuario import usuario
from app.controllers.serie import serie

#from app.controllers.usuario import usuario
#from app.controllers.temporada import temporada
#from app.controllers.serie import serie


from flask import render_template, request,redirect
from flask import Blueprint, flash, Flask
from app.models.Form import formulario
from app.models.login import formLogin
from app.models.classes.serie import Serie
from app.models.usuario import Usuario
from flask_sqlalchemy import SQLAlchemy
from app import db
from app.models.departamento import Departamento



app.register_blueprint(control)
app.register_blueprint(usuario)
app.register_blueprint(serie)

@app.route('/')
def index():
    return redirect(control.url_prefix)


if __name__ == '__main__':
    port = int(os.environ.get("PORT", 8080))
    app.run('0.0.0.0', port=port)


